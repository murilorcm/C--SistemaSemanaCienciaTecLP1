﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace melhor_prato_feito
{
    public partial class frmPrincipal : Form
    {
        public struct alimento
        {
            public double preco, valorCalorico;
            public string nome;
        }

        int i = 0;
        const int MAX = 3;
        alimento[] tipoAlimento = new alimento[MAX];

        public frmPrincipal()
        {
            InitializeComponent();
            preCadastroAlimento(tipoAlimento);
            lblNomeAlimento.Text = Convert.ToString(tipoAlimento[0].nome);
        }

        public void preCadastroAlimento(alimento[] tipoAlimento)
        {
            tipoAlimento[0].nome = "Arroz";
            tipoAlimento[0].valorCalorico = 86;

            tipoAlimento[1].nome = "Feijão";
            tipoAlimento[1].valorCalorico = 40;

            tipoAlimento[2].nome = "Batata";
            tipoAlimento[2].valorCalorico = 32;

        }
        public void limpar()
        {
            lblNomeAlimento.Text = "Alimento";
            mskAlimento.Text = "";
        }
        public void ativaCadastroPreco()
        {
            limpar();
            txtAlimento.Enabled = true;
            btnCadastraPreco.Enabled = true;
            btnIndicarPrato.Enabled = false;
            i = 0;
        }
        public void desativaCadastroPreco()
        {
            limpar();
            txtAlimento.Enabled = false;
            btnCadastraPreco.Enabled = false;
            btnIndicarPrato.Enabled = true;
        }
        public void exibePreco()
        {
            lbl0.Text = tipoAlimento[0].nome + ": R$" + Convert.ToString(tipoAlimento[0].preco);
            lbl1.Text = tipoAlimento[1].nome + ": R$" + Convert.ToString(tipoAlimento[1].preco);
            lbl2.Text = tipoAlimento[2].nome + ": R$" + Convert.ToString(tipoAlimento[2].preco);
        }
        public void cadastraPreco()
        {
            if (txtAlimento.Text == "")
            {
                MessageBox.Show("Insira o preço do Alimento, caso não queira o alimento insira 0 (Zero).");
            }
            else
            {
                tipoAlimento[i].preco = double.Parse(txtAlimento.Text);
                i++;

                limpar();
                if (i < MAX)
                {
                    lblNomeAlimento.Text = Convert.ToString(tipoAlimento[i].nome);
                }
                else
                {
                    MessageBox.Show("Todos Alimentos Inseridos, Clique em Indicar Prato!");
                    desativaCadastroPreco();
                    exibePreco();
                }
            }
        }
        private void btnCadastraPreco_Click(object sender, EventArgs e)
        {
            cadastraPreco();
        }

        private void btnRecomecar_Click(object sender, EventArgs e)
        {
            limpar();
            ativaCadastroPreco();
            lblNomeAlimento.Text = Convert.ToString(tipoAlimento[0].nome);
        }
    }
}
