﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace melhor_prato_feito
{
    public partial class frmCadastro : Form
    {
        public struct alimento
        {
            public double valorCalorico, precoKcal;
            public string preco, nome;
        }
        const int MAX = 29;

        alimento[] tipoAlimento = new alimento[MAX];
        alimento[] entrada = new alimento[MAX];
        alimento[] mistura = new alimento[MAX];
        alimento[] guarnicao = new alimento[MAX];
        alimento[] salada = new alimento[MAX];

        int i = -1;

        public frmCadastro()
        {
            InitializeComponent();
            preCadastroAlimento(tipoAlimento);
            limpar();
        }

        public void preCadastroAlimento(alimento[] tipoAlimento)
        {
            lstAlimentos.Items.Clear();
            lstPrato.Items.Clear();

            //Categoria de Entrada
            tipoAlimento[0].nome = "Arroz";
            tipoAlimento[0].valorCalorico = 130;
            tipoAlimento[0].preco = "0000";
            lstAlimentos.Items.Add("0 - Arroz 130Kcal");

            tipoAlimento[1].nome = "Feijão";
            tipoAlimento[1].valorCalorico = 76;
            tipoAlimento[1].preco = "0000";
            lstAlimentos.Items.Add("1 - Feijão 76Kcal");

            tipoAlimento[2].nome = "Macarrão";
            tipoAlimento[2].valorCalorico = 154;
            tipoAlimento[2].preco = "0000";
            lstAlimentos.Items.Add("2 - Macarrão 154Kcal");

            //Mistura          
            tipoAlimento[3].nome = "Alcatra assada";
            tipoAlimento[3].valorCalorico = 206;
            tipoAlimento[3].preco = "0000";
            lstAlimentos.Items.Add("3 - Alcatra assada 206Kcal");

            tipoAlimento[4].nome = "Alcatra frita";
            tipoAlimento[4].valorCalorico = 235;
            tipoAlimento[4].preco = "0000";
            lstAlimentos.Items.Add("4 - Alcatra frita 235Kcal");

            tipoAlimento[5].nome = "Bacon fatiado";
            tipoAlimento[5].valorCalorico = 314;
            tipoAlimento[5].preco = "0000";
            lstAlimentos.Items.Add("5 - Bacon fatiado 314Kcal");

            tipoAlimento[6].nome = "Almôndega de carne";
            tipoAlimento[6].valorCalorico = 203;
            tipoAlimento[6].preco = "0000";
            lstAlimentos.Items.Add("6 - Almôndega de carne 203Kcal");

            tipoAlimento[7].nome = "Bisteca de porco";
            tipoAlimento[7].valorCalorico = 337;
            tipoAlimento[7].preco = "0000";
            lstAlimentos.Items.Add("7 - Bisteca de porco 337Kcal");

            tipoAlimento[8].nome = "Costelinha de porco";
            tipoAlimento[8].valorCalorico = 483;
            tipoAlimento[8].preco = "0000";
            lstAlimentos.Items.Add("8 - Costelinha de porco 483Kcal");

            tipoAlimento[9].nome = "Coxa de frango assada";
            tipoAlimento[9].valorCalorico = 110;
            tipoAlimento[9].preco = "0000";
            lstAlimentos.Items.Add("9 - Coxa de frango assada 110Kcal");

            tipoAlimento[10].nome = "Coxa de frango cozida";
            tipoAlimento[10].valorCalorico = 120;
            tipoAlimento[10].preco = "0000";
            lstAlimentos.Items.Add("10 - Coxa de frango cozida 120Kcal");

            tipoAlimento[11].nome = "Cupim assado";
            tipoAlimento[11].valorCalorico = 250;
            tipoAlimento[11].preco = "0000";
            lstAlimentos.Items.Add("11 - Cupim assado 250Kcal");

            tipoAlimento[12].nome = "Fígado bovino frito";
            tipoAlimento[12].valorCalorico = 210;
            tipoAlimento[12].preco = "0000";
            lstAlimentos.Items.Add("12 - Fígado bovino frito 210Kcal");

            tipoAlimento[13].nome = "Filé de frango frito";
            tipoAlimento[13].valorCalorico = 139;
            tipoAlimento[13].preco = "0000";
            lstAlimentos.Items.Add("13 - Filé de frango frito 139Kcal");

            tipoAlimento[14].nome = "Hamburger ao sugo";
            tipoAlimento[14].valorCalorico = 242;
            tipoAlimento[14].preco = "0000";
            lstAlimentos.Items.Add("14 - Hamburger ao sugo 242Kcal");

            tipoAlimento[15].nome = "Maminha assada";
            tipoAlimento[15].valorCalorico = 141;
            tipoAlimento[15].preco = "0000";
            lstAlimentos.Items.Add("15 - Maminha assada 141Kcal");

            tipoAlimento[16].nome = "Músculo cozido";
            tipoAlimento[16].valorCalorico = 180;
            tipoAlimento[16].preco = "0000";
            lstAlimentos.Items.Add("16 - Músculo cozido 180Kcal");

            tipoAlimento[17].nome = "Peito de frango sem pele";
            tipoAlimento[17].valorCalorico = 100;
            tipoAlimento[17].preco = "0000";
            lstAlimentos.Items.Add("17 - Peito de frango sem pele 100Kcal");

            tipoAlimento[18].nome = "Linguiça assada";
            tipoAlimento[18].valorCalorico = 255;
            tipoAlimento[18].preco = "0000";
            lstAlimentos.Items.Add("18 - Linguiça assada 255Kcal");

            //Guarnição
            tipoAlimento[19].nome = "Farofa";
            tipoAlimento[19].valorCalorico = 169;
            tipoAlimento[19].preco = "0000";
            lstAlimentos.Items.Add("19 - Farofa 169Kcal");

            tipoAlimento[20].nome = "Mandioca Frita";
            tipoAlimento[20].valorCalorico = 352;
            tipoAlimento[20].preco = "0000";
            lstAlimentos.Items.Add("20 - Mandioca frita 169Kcal");

            tipoAlimento[21].nome = "Batata frita";
            tipoAlimento[21].valorCalorico = 314;
            tipoAlimento[21].preco = "0000";
            lstAlimentos.Items.Add("21 - Batata frita 314Kcal");

            tipoAlimento[22].nome = "Batata doce frita";
            tipoAlimento[22].valorCalorico = 383;
            tipoAlimento[22].preco = "0000";
            lstAlimentos.Items.Add("22 - Batata doce frita 383Kcal");

            tipoAlimento[23].nome = "Beringela ao molho branco";
            tipoAlimento[23].valorCalorico = 196;
            tipoAlimento[23].preco = "0000";
            lstAlimentos.Items.Add("23 - Beringela ao molho branco 196Kcal");

            //Salada
            tipoAlimento[24].nome = "Alface";
            tipoAlimento[24].valorCalorico = 20;
            tipoAlimento[24].preco = "0000";
            lstAlimentos.Items.Add("24 - Alface 20Kcal");

            tipoAlimento[25].nome = "Tomate";
            tipoAlimento[25].valorCalorico = 20;
            tipoAlimento[25].preco = "0000";
            lstAlimentos.Items.Add("25 - Tomate 20Kcal");

            tipoAlimento[26].nome = "Vagem cozida";
            tipoAlimento[26].valorCalorico = 52;
            tipoAlimento[26].preco = "0000";
            lstAlimentos.Items.Add("24 - Vagem cozida 20Kcal");

            tipoAlimento[27].nome = "Cenoura cozida com couve-flor";
            tipoAlimento[27].valorCalorico = 48;
            tipoAlimento[27].preco = "0000";
            lstAlimentos.Items.Add("27 - Cenoura cozida com couve-flor 48Kcal");

            tipoAlimento[28].nome = "Beterraba";
            tipoAlimento[28].valorCalorico = 55;
            tipoAlimento[28].preco = "0000";
            lstAlimentos.Items.Add("28 - Beterraba 55Kcal");
        }
        public void limpar()
        {
            lblNomeAlimento.Text = "Alimento";
            mskAlimento.Text = "0000";
            i = -1;
        }
        public void cadastraPreco()
        {
            if (i == -1)
            {
                MessageBox.Show("Nenhum alimento selecionado!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    tipoAlimento[i].preco = mskAlimento.Text.Substring(3, 5);
                    limpar();
                }
                catch (Exception)
                {
                    MessageBox.Show("O preço não foi inserido corretamente! \n\n Preencha com ZEROS se não quiser o alimento.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void btnCadastraPreco_Click(object sender, EventArgs e)
        {
            cadastraPreco();
        }

        private void btnRecomecar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja Recomeçar a Aplicação?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                limpar();
                preCadastroAlimento(tipoAlimento);
            }
        }
        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja encerrar a Aplicação?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        public void exibeAlimentoCadastro()
        {
            lblNomeAlimento.Text = tipoAlimento[i].nome;
            mskAlimento.Text = tipoAlimento[i].preco;
        }
        public void lstAlimentos_DoubleClick(object sender, EventArgs e)
        {
            i = int.Parse((lstAlimentos.SelectedItem).ToString().Substring(0, 2));
            exibeAlimentoCadastro();
        }

        private void lstAlimentos_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabMelhorPrato_Click(object sender, EventArgs e)
        {

        }
        public void calcularMedia(alimento[] tipoAlimento)
        {
            int j;

            for(j=0; j<MAX; j++)
            {
                tipoAlimento[j].precoKcal = double.Parse(tipoAlimento[j].preco) * tipoAlimento[j].valorCalorico;
            }
        }
        public void separarAlimento(alimento[] tipoAlimento, alimento[] entrada, alimento[] mistura, alimento[] guarnicao, alimento[] salada)
        {
            int j=0, k=0;

            for(j=0; j<3; j++, k++)
            {
                entrada[j] = tipoAlimento[k];
            }

            for(j=0; j<16; j++, k++)
            {
                mistura[j] = tipoAlimento[k];
            }

            for (j=0; j<5; j++, k++)
            {
                guarnicao[j] = tipoAlimento[k];
            }
            
            for (j=0; j<5; j++, k++)
            {
                salada[j] = tipoAlimento[k];
            }
        }
        public void indicarPrato(alimento[] tipoAlimento, alimento[] entrada, alimento[] mistura, alimento[] guarnicao, alimento[] salada)
        {
            int j = 0, imaior=0;
            double maior=0;
            if ((entrada[0].precoKcal + entrada[1].precoKcal > entrada[2].precoKcal) && entrada[1].precoKcal != 0)
            {
                lstPrato.Items.Add(entrada[0].nome);
                lstPrato.Items.Add(entrada[0].nome);
            }
            else if ((entrada[0].precoKcal + entrada[1].precoKcal > entrada[2].precoKcal) && entrada[1].precoKcal == 0)
            {
                lstPrato.Items.Add(entrada[0].nome);
            }
            else
            {
                lstPrato.Items.Add(entrada[2].nome);
            }

            for (j = 0; j < 16; j++)
            {
                if (j == 0)
                {
                    maior = mistura[j].precoKcal;
                    imaior = j;
                }
                else if (mistura[j].precoKcal > maior)
                {
                    maior = mistura[j].precoKcal;
                    imaior = j;
                }
            }
            lstPrato.Items.Add(mistura[imaior].nome);

            for (j = 0; j < 5; j++)
            {
                if (j == 0)
                {
                    maior = guarnicao[j].precoKcal;
                    imaior = j;
                }
                else if (guarnicao[j].precoKcal > maior)
                {
                    maior = guarnicao[j].precoKcal;
                    imaior = j;
                }
            }
            lstPrato.Items.Add(guarnicao[imaior].nome);

            for (j = 0; j < 5; j++)
            {
                if (j == 0)
                {
                    maior = salada[j].precoKcal;
                    imaior = j;
                }
                else if (salada[j].precoKcal > maior)
                {
                    maior = salada[j].precoKcal;
                    imaior = j;
                }
            }
            lstPrato.Items.Add(salada[imaior].nome);

        }
        private void btnIndicarPrato_Click(object sender, EventArgs e)
        {
            lstPrato.Items.Clear();
            calcularMedia(tipoAlimento);
            separarAlimento(tipoAlimento, entrada, mistura, guarnicao, salada);
            indicarPrato(tipoAlimento, entrada, mistura, guarnicao, salada);
        }
        public void ajudaAnuncio()
        {
            frmPrincipal anuncio = new frmPrincipal();
            anuncio.Show();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ajudaAnuncio();
        }
    }
}
